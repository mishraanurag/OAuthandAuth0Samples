# Token Delegation Example

This example show Angularjs client side authentication + server side authentication to two different APIs. A delegation token is requested in order to communicate with the secondary API.

In order to run the example, in this current folder and run:
```sh
npm install
```
After doing that, start the server by doing:
```sh
node server.js
```

Open your browser at [http://localhost:3000/](http://localhost:3000).

