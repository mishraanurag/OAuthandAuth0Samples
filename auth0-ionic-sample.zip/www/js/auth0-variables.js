var AUTH0_CLIENT_ID='ogDaDLFHlZ6gc5WXElxGjNw5i3Bocafg'; 
var AUTH0_DOMAIN='anuragm.auth0.com'; 
var AUTH0_CALLBACK_URL=location.href;